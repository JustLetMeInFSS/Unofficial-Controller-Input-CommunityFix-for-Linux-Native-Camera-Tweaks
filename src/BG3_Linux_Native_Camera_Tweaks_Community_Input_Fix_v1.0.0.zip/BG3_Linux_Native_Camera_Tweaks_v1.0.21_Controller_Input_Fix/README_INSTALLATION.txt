BALDUR'S GATE 3 - LINUX NATIVE CAMERA TWEAKS
Controller Input Fix for v1.0.21
============================================

ABOUT
-----
This is a community bug-fix build of Linux Native Camera Tweaks for the
native Linux version of Baldur's Gate 3. It keeps the original free camera and
unrestricted zoom while improving controller input, zoom stability, and
mouse/controller switching.

Original Linux mod: Biiinks78 / 0x1496FD0


REQUIREMENTS
------------
- Native Linux x86-64 version of Baldur's Gate 3
- glibc 2.17 or newer
- Supported game build: 4.1.1.7398727 or 4.1.1.7209685

Unsupported executables are detected before patching and leave the mod
disabled safely.


INSTALLATION
------------
1. Extract this archive.

2. Place linux_native_camera_tweaks.so in any permanent location accessible
   to your user account.

3. Open Steam:
   Baldur's Gate 3 > Properties > General > Launch Options

4. Enter the absolute path to the file:

   LD_PRELOAD="/absolute/path/to/linux_native_camera_tweaks.so" %command%

5. Launch the game normally. No installer, mod manager, or sudo is required.

If another mod already uses LD_PRELOAD, keep both absolute paths in the same
quoted value, separated by a colon.


CONTROLS
--------
- Right-stick Y: vertical camera pitch
- Hold L3 + right-stick Y: zoom
- Normal L3 click: forwarded to BG3 when it was not used for zoom
- Hold the configured mouse-rotate button: free mouse camera pitch


CONFIGURATION
-------------
The config is created automatically on first launch:

   ${XDG_CONFIG_HOME:-$HOME/.config}/bg3-native-camera-tweaks.conf

Default settings:

   controller_pitch_sensitivity=0.25
   controller_zoom_speed=15.00
   mouse_pitch_sensitivity=1.50
   invert_controller_pitch=false

Restart BG3 after changing the config. Existing values are preserved; missing
settings are added automatically.


WHAT THIS BUILD FIXES
---------------------
- Frame-rate-dependent controller pitch
- Excessive vertical controller sensitivity
- Controller input delay caused by consumed SDL queue events
- Zoom jitter from mismatched internal zoom values
- Stuck or unexpectedly inverted controller input states
- Unreliable L3 zoom and normal L3-click handling
- Mouse behavior changing after switching input devices
- User-specific paths and newer-than-required glibc dependencies


KNOWN LIMITATION
----------------
BG3's dedicated Tactical Camera mode or automatic tactical transition may not
work correctly with the unrestricted Linux zoom implementation.

Keyboard and mouse users can use the free top-down camera and toggle character
outlines with the Grave/Caret key (commonly ^, `, or ~ depending on the
keyboard layout). Switching to controller mode may clear those outlines.

This release deliberately avoids simulated keyboard shortcuts or experimental
controller hooks so the confirmed L3 and camera behavior remains stable.


VERIFYING THE DOWNLOAD
----------------------
From this folder, run:

   sha256sum -c SHA256SUMS.txt


SOURCE AND CREDITS
------------------
Original Linux mod and source:
https://github.com/0x1496FD0/Baldur-s-Gate-3-Linux-Native-Camera-Tweaks

Original Nexus Mods page:
https://www.nexusmods.com/baldursgate3/mods/23896

Windows camera and input reference by ersh1:
https://github.com/ersh1/BG3_NativeCameraTweaks

The original creator remains fully credited. Distribution and reuse must
follow the permissions stated on the original Nexus Mods page. This build is
not intended for sale, paid distribution, or Donation Points.
